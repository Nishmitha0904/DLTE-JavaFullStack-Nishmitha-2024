package org.database;

public interface StorageTarget {
    UserRepository getUserRepository();
}
