package org.example;

public interface StorageTarget {
    UserRepository getUserRepository();
}
